import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from forgot_password import ForgotPasswordDialog
from login_main import LoginWindow
import requests

class ForgotPasswordWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = ForgotPasswordDialog()
        self.ui.setupUi(self)

        self.ui.confirmButton.clicked.connect(self.handle_confirm)
        self.ui.backLabel.mousePressEvent = self.show_login

    def handle_confirm(self):
        username = self.ui.usernameInput.text()
        email = self.ui.emailInput.text()
        verification_code = self.ui.verificationCodeInput.text()

        if not username or not email or not verification_code:
            QtWidgets.QMessageBox.warning(self, "Thông báo", "Vui lòng nhập đầy đủ thông tin!")
            return

        api_url = "http://127.0.0.1:8000/api/email"
        payload = {
            "username": username,
            "email": email,
            "verification_code": verification_code,
        }

        try:
            response = requests.post(api_url, json=payload)
            if response.status_code == 200:
                QtWidgets.QMessageBox.information(self, "Thành công", "Yêu cầu quên mật khẩu thành công. Vui lòng kiểm tra email của bạn!")
            else:
                QtWidgets.QMessageBox.warning(self, "Thất bại", f"Lỗi từ server: {response.text}")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Lỗi kết nối", f"Không thể kết nối đến server. Chi tiết lỗi: {str(e)}")

    def show_login(self, event):
        self.login_window = LoginWindow()
        self.login_window.show()

        self.hide()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = ForgotPasswordWindow()
    window.show()
    sys.exit(app.exec_())
