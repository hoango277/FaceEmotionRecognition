import json
import requests
import numpy as np
import cv2
import sys
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.QtCore import QTimer, Qt
from camera import Ui_CameraWindow
from home_main import HomeWindow

class CameraWindow(QMainWindow, Ui_CameraWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.camera = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)

        self.startButton.clicked.connect(self.start_camera)
        self.stopButton.clicked.connect(self.stop_camera)
        self.exitButton.clicked.connect(self.exit_camera)

        self.camera = cv2.VideoCapture()  # Khởi tạo đối tượng camera

    def get_token(self):
        try:
            with open("config.json", "r") as f:
                config = json.load(f)
                return config.get("token", "")
        except FileNotFoundError:
            return ""

    def start_camera(self):
        api_url = "http://127.0.0.1:8000/api/stream"
        token = self.get_token()

        headers = {"Authorization": f"Bearer {token}"}
        try:
            response = requests.get(api_url, headers=headers)
            if response.status_code == 200:
                if not self.camera.isOpened():
                    self.camera.open(0)
                self.timer.start(30)  # Cập nhật khung hình mỗi 30ms
                QMessageBox.information(self, "Thành công", "Camera đã được bật!")
            else:
                QMessageBox.warning(self, "Lỗi", f"Lỗi từ server: {response.text}")
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Không thể kết nối đến server: {e}")

    def stop_camera(self):
        """Dừng camera"""
        api_url = "http://127.0.0.1:8000/api/stop"
        token = self.get_token()

        headers = {"Authorization": f"Bearer {token}"}
        try:
            response = requests.get(api_url, headers=headers)
            if response.status_code == 200:
                self.timer.stop()
                if self.camera.isOpened():
                    self.camera.release()
                QMessageBox.information(self, "Thành công", "Camera đã được dừng!")
            else:
                QMessageBox.warning(self, "Lỗi", f"Lỗi từ server: {response.text}")
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Không thể kết nối đến server: {e}")

    def update_frame(self):
        if self.camera.isOpened():
            ret, frame = self.camera.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                h, w, ch = frame.shape
                bytes_per_line = ch * w
                qt_image = QImage(frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
                self.cameraDisplayLabel.setPixmap(QPixmap.fromImage(qt_image))
            else:
                QMessageBox.warning(self, "Lỗi", "Không thể đọc khung hình từ camera.")

    def exit_camera(self):
        self.timer.stop()
        if self.camera.isOpened():
            self.camera.release()
        self.close()

        self.home_window = HomeWindow()
        self.home_window.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CameraWindow()
    window.show()
    sys.exit(app.exec_())
