from PyQt5 import QtCore, QtGui, QtWidgets
import sys

class Ui_UpdateInfoDialog(object):
    def setupUi(self, UpdateInfoDialog):
        UpdateInfoDialog.setObjectName("UpdateInfoDialog")
        UpdateInfoDialog.resize(800, 600)

        self.centralwidget = QtWidgets.QWidget(UpdateInfoDialog)
        self.centralwidget.setGeometry(QtCore.QRect(0, 0, 800, 600))
        self.centralwidget.setStyleSheet("background-color: white;")
        self.centralwidget.setObjectName("centralwidget")

        self.rightPanel = QtWidgets.QWidget(self.centralwidget)
        self.rightPanel.setGeometry(QtCore.QRect(200, 50, 400, 380))
        self.rightPanel.setStyleSheet("background-color: white;")
        self.rightPanel.setObjectName("rightPanel")

        self.titleLabel = QtWidgets.QLabel(self.rightPanel)
        self.titleLabel.setGeometry(QtCore.QRect(50, 10, 300, 50))
        self.titleLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.titleLabel.setStyleSheet("font-size: 25px; font-weight: bold; color: #333333;")
        self.titleLabel.setText("Cập nhật thông tin")
        self.titleLabel.setObjectName("titleLabel")

        self.firstNameLabel = QtWidgets.QLabel(self.rightPanel)
        self.firstNameLabel.setGeometry(QtCore.QRect(50, 70, 140, 20))
        self.firstNameLabel.setText("Họ")
        self.firstNameLabel.setStyleSheet("font-size: 14px; color: #333333;")

        self.firstNameInput = QtWidgets.QLineEdit(self.rightPanel)
        self.firstNameInput.setGeometry(QtCore.QRect(50, 90, 140, 35))
        self.firstNameInput.setStyleSheet("background-color: #F5F5F5; border: 2px solid #B0B0B0; border-radius: 5px;")
        self.firstNameInput.setObjectName("firstNameInput")

        self.lastNameLabel = QtWidgets.QLabel(self.rightPanel)
        self.lastNameLabel.setGeometry(QtCore.QRect(210, 70, 140, 20))
        self.lastNameLabel.setText("Tên")
        self.lastNameLabel.setStyleSheet("font-size: 14px; color: #333333;")

        self.lastNameInput = QtWidgets.QLineEdit(self.rightPanel)
        self.lastNameInput.setGeometry(QtCore.QRect(210, 90, 140, 35))
        self.lastNameInput.setStyleSheet("background-color: #F5F5F5; border: 2px solid #B0B0B0; border-radius: 5px;")
        self.lastNameInput.setObjectName("lastNameInput")

        self.emailLabel = QtWidgets.QLabel(self.rightPanel)
        self.emailLabel.setGeometry(QtCore.QRect(50, 130, 300, 20))
        self.emailLabel.setText("Email")
        self.emailLabel.setStyleSheet("font-size: 14px; color: #333333;")

        self.emailInput = QtWidgets.QLineEdit(self.rightPanel)
        self.emailInput.setGeometry(QtCore.QRect(50, 150, 300, 35))
        self.emailInput.setStyleSheet("background-color: #F5F5F5; border: 2px solid #B0B0B0; border-radius: 5px;")
        self.emailInput.setObjectName("emailInput")

        self.passwordLabel = QtWidgets.QLabel(self.rightPanel)
        self.passwordLabel.setGeometry(QtCore.QRect(50, 190, 300, 20))
        self.passwordLabel.setText("Mật khẩu")
        self.passwordLabel.setStyleSheet("font-size: 14px; color: #333333;")

        self.passwordInput = QtWidgets.QLineEdit(self.rightPanel)
        self.passwordInput.setGeometry(QtCore.QRect(50, 210, 300, 35))
        self.passwordInput.setEchoMode(QtWidgets.QLineEdit.Password)
        self.passwordInput.setStyleSheet("background-color: #F5F5F5; border: 2px solid #B0B0B0; border-radius: 5px;")
        self.passwordInput.setObjectName("passwordInput")

        self.updateButton = QtWidgets.QPushButton(self.rightPanel)
        self.updateButton.setGeometry(QtCore.QRect(50, 260, 300, 45))
        self.updateButton.setStyleSheet(
            "background-color: #5DADE2; color: white; font-size: 16px; border: 2px solid #007BFF; border-radius: 5px;")
        self.updateButton.setText("Cập nhật thông tin")
        self.updateButton.setObjectName("updateButton")

        self.backLabel = QtWidgets.QLabel(self.rightPanel)
        self.backLabel.setGeometry(QtCore.QRect(50, 320, 300, 30))
        self.backLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.backLabel.setText("Quay lại")
        self.backLabel.setStyleSheet("font-size: 16px; color: #007BFF; cursor: pointer;")

        self.retranslateUi(UpdateInfoDialog)
        QtCore.QMetaObject.connectSlotsByName(UpdateInfoDialog)

    def retranslateUi(self, UpdateInfoDialog):
        _translate = QtCore.QCoreApplication.translate
        UpdateInfoDialog.setWindowTitle(_translate("UpdateInfoDialog", "Cập nhật thông tin"))
