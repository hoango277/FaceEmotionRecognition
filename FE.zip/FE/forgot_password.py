from PyQt5 import QtCore, QtGui, QtWidgets


class ForgotPasswordDialog(object):
    def setupUi(self, ForgotPasswordDialog):
        ForgotPasswordDialog.setObjectName("ForgotPasswordDialog")
        ForgotPasswordDialog.resize(400, 400)

        self.centralwidget = QtWidgets.QWidget(ForgotPasswordDialog)
        self.centralwidget.setObjectName("centralwidget")

        self.titleLabel = QtWidgets.QLabel(self.centralwidget)
        self.titleLabel.setGeometry(QtCore.QRect(50, 30, 300, 50))
        self.titleLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.titleLabel.setObjectName("titleLabel")
        self.titleLabel.setStyleSheet("font-size: 25px; font-weight: bold;")

        self.usernameInput = QtWidgets.QLineEdit(self.centralwidget)
        self.usernameInput.setGeometry(QtCore.QRect(50, 100, 300, 45))
        self.usernameInput.setObjectName("usernameInput")
        self.usernameInput.setStyleSheet("border: 1px solid gray; padding: 5px; border-radius: 5px;")

        self.emailInput = QtWidgets.QLineEdit(self.centralwidget)
        self.emailInput.setGeometry(QtCore.QRect(50, 170, 300, 45))
        self.emailInput.setObjectName("emailInput")
        self.emailInput.setStyleSheet("border: 1px solid gray; padding: 5px; border-radius: 5px;")

        self.sendCodeLabel = QtWidgets.QLabel(self.centralwidget)
        self.sendCodeLabel.setGeometry(QtCore.QRect(50, 215, 100, 20))
        self.sendCodeLabel.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignBottom)
        self.sendCodeLabel.setObjectName("sendCodeLabel")
        self.sendCodeLabel.setStyleSheet("font-size: 14px; color: #007BFF; font-weight: bold; text-decoration: underline;")

        self.verificationCodeInput = QtWidgets.QLineEdit(self.centralwidget)
        self.verificationCodeInput.setGeometry(QtCore.QRect(50, 245, 300, 45))
        self.verificationCodeInput.setObjectName("verificationCodeInput")
        self.verificationCodeInput.setStyleSheet("border: 1px solid gray; padding: 5px; border-radius: 5px;")

        self.confirmButton = QtWidgets.QPushButton(self.centralwidget)
        self.confirmButton.setGeometry(QtCore.QRect(50, 310, 300, 45))
        self.confirmButton.setObjectName("confirmButton")
        self.confirmButton.setStyleSheet("background-color: #5DADE2; color: white; font-size: 16px; font-weight: bold; border-radius: 5px;")

        # Thêm QLabel cho dòng chữ "Quay lại"
        self.backLabel = QtWidgets.QLabel(self.centralwidget)
        self.backLabel.setGeometry(QtCore.QRect(50, 360, 300, 30))  # Vị trí dưới nút "Tiếp tục"
        self.backLabel.setAlignment(QtCore.Qt.AlignCenter)  # Căn giữa
        self.backLabel.setObjectName("backLabel")
        self.backLabel.setStyleSheet("font-size: 14px; color: #007BFF; font-weight: bold; text-decoration: underline;")
        self.backLabel.setText("Quay lại")

        ForgotPasswordDialog.setCentralWidget(self.centralwidget)
        self.retranslateUi(ForgotPasswordDialog)
        QtCore.QMetaObject.connectSlotsByName(ForgotPasswordDialog)

    def retranslateUi(self, ForgotPasswordDialog):
        _translate = QtCore.QCoreApplication.translate
        ForgotPasswordDialog.setWindowTitle(_translate("ForgotPasswordDialog", "Quên mật khẩu"))
        self.titleLabel.setText(_translate("ForgotPasswordDialog", "Quên mật khẩu"))
        self.usernameInput.setPlaceholderText(_translate("ForgotPasswordDialog", "Tên người dùng"))
        self.emailInput.setPlaceholderText(_translate("ForgotPasswordDialog", "Email"))
        self.sendCodeLabel.setText(_translate("ForgotPasswordDialog", "Gửi mã"))
        self.verificationCodeInput.setPlaceholderText(_translate("ForgotPasswordDialog", "Mã xác nhận"))
        self.confirmButton.setText(_translate("ForgotPasswordDialog", "Tiếp tục"))
