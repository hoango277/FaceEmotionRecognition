from PyQt5 import QtWidgets
import requests
import sys
from home_main import HomeWindow
from user import Ui_UpdateInfoDialog

class UserWindow(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_UpdateInfoDialog()
        self.ui.setupUi(self)

        self.ui.backLabel.mousePressEvent = self.goBack
        self.ui.updateButton.clicked.connect(self.update_user_info)

    def update_user_info(self):
        username = self.ui.emailInput.text()
        password = self.ui.passwordInput.text()

        if not username or not password:
            QtWidgets.QMessageBox.warning(self, "Thông báo", "Vui lòng nhập đầy đủ thông tin!")
            return

        api_url = "http://127.0.0.1:8000/api/users"
        payload = {
            "username": username,
            "password": password
        }

        try:
            response = requests.post(api_url, json=payload)
            if response.status_code == 200:
                QtWidgets.QMessageBox.information(self, "Thành công", "Cập nhật thông tin thành công!")
            else:
                QtWidgets.QMessageBox.warning(self, "Thất bại", f"Lỗi từ server: {response.text}")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Lỗi kết nối", f"Không thể kết nối đến server. Chi tiết lỗi: {str(e)}")

    def goBack(self, event):
        self.homeWindow = HomeWindow()
        self.homeWindow.show()
        self.close()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = UserWindow()
    window.show()
    sys.exit(app.exec_())
